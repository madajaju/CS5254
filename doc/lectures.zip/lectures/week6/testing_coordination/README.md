# Testing Coordination

## Objective
- Develop a suite of tests that specifically target the "joints" where multiple objects coordinate.
- Learn how to simulate delayed, out-of-order, and duplicate events.

## Key Concepts
- **Joint Testing**: Testing the interaction between Object A and Object B, rather than just their individual methods.
- **Artificial Latency**: Intentionally slowing down one branch of a parallel workflow to see if the rest of the system handles it correctly.
- **Chaos Testing (Small Scale)**: Randomly reordering the sequence of incoming "Asset Complete" signals.
- **Stress Testing Coordination**: Running 50 workflows at once to find the one timing edge case that leads to a deadlock.

## Examples
- **Podcast Domain**: 
    - *Test*: Generate the transcript *before* the audio ingest and see if the system correctly waits for the audio before proceeding to show notes.
    - *Test*: Send two "Audio Cleaned" signals for the same episode.
- **Order System**: Simulating a payment confirmation that arrives *after* the shipping timeout.

## Link to Assignment
- **A2 Alignment**: Part 4 of A2 requires you to "Create Coordination Tests." This lecture gives you a list of specific test cases (Out-of-Order, Duplicate, Delayed) that you should implement.
