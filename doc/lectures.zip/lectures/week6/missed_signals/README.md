# Missed Signals

## Objective
- Understand how timing differences can cause signals between components to be lost or ignored.
- Learn why "Stateless Signaling" is dangerous in coordinated systems.

## Key Concepts
- **The Lost Signal**: Thread A sends a signal (e.g., `notify()`) before Thread B is actually waiting for it. Thread B then waits forever.
- **Race to Wait**: When a thread checks a condition, finds it's not met, but then the condition *is* met before the thread starts waiting.
- **State-Based Signaling**: Designing signals that check the current state of an object (e.g., "Is the audio ready?") rather than just reacting to a momentary event.

## Examples
- **Podcast Domain**: 
    - *Scenario*: The `Ingestor` signals "File Ready." The `Cleaner` hasn't finished its setup and isn't listening yet. The `Cleaner` then starts listening, but the signal is already gone.
- **Fix**: The `Cleaner` checks `episode.isIngested()` before it ever starts waiting for a signal.

## Link to Assignment
- **A2 Alignment**: Part 5 of A2 lists "missed signal" as a coordination failure. This lecture explains how to use `sleep()` or artificial delays to force a "race to wait" scenario in your tests.
