# Livelock vs Deadlock

## Objective
- Distinguish between systems that are frozen (Deadlock) and systems that are actively trying but failing to proceed (Livelock).
- Recognize the "Polite Thread" problem.

## Key Concepts
- **Livelock**: A state where two or more threads continuously change their state in response to each other without making any progress.
- **Resource Rejection**: When Thread A and Thread B both release their resource to be "polite" to the other, then both try to grab it again at the same time, repeating the cycle.
- **Spinning vs. Waiting**: Deadlocked threads are usually waiting (sleeping); livelocked threads are usually active (consuming CPU).

## Examples
- **Podcast Domain**: 
    - *Scenario*: Two workers both need a "Publishing Slot." Worker A grabs a slot, sees Worker B also needs one, and releases it. Worker B does the same. They both keep releasing and re-grabbing the slot indefinitely.
- **Walking in a Hallway**: Two people trying to pass each other, both stepping to the same side at the same time repeatedly.

## Link to Assignment
- **A2 Alignment**: Livelock is a more subtle failure to demonstrate in A2 Part 5. This lecture helps you understand the logs needed to prove that your threads are "working" but "getting nowhere."
