# Deadlocks Explained

## Objective
- Understand the "Circular Wait" condition that leads to deadlocks.
- Identify how resource contention in workflows can freeze a system.

## Key Concepts
- **Deadlock**: A state where two or more threads are waiting for each other to release resources, and none can proceed.
- **The Four Conditions (Coffman Conditions)**: Mutual Exclusion, Hold and Wait, No Preemption, and Circular Wait.
- **Circular Wait**: Thread A holds Resource 1 and waits for Resource 2; Thread B holds Resource 2 and waits for Resource 1.

## Examples
- **Podcast Domain**:
    - *Scenario*: Thread 1 locks `Episode-A` to add a transcript and then tries to lock `Episode-B` to link them. Simultaneously, Thread 2 locks `Episode-B` and tries to lock `Episode-A`.
- **Order System**: Thread 1 locks `Inventory` then `Payment`. Thread 2 locks `Payment` then `Inventory`.

## Link to Assignment
- **A2 Alignment**: Part 5 of A2 requires you to "demonstrate coordination failure," and Deadlock is one of the primary options. This lecture shows you how to design a scenario where your system intentionally freezes.
