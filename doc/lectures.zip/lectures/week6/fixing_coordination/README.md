# Fixing Coordination

## Objective
- Learn how to redesign coordination logic to be more robust against timing and ordering failures.
- Compare different "Repair" strategies for A2.

## Key Concepts
- **Explicit Wait States**: Ensuring a component waits on a specific *condition* (state), not just a *signal* (event).
- **Lock Ordering**: Preventing deadlocks by always acquiring multiple locks in the exact same alphabetical or numerical order.
- **Idempotent Transitions**: Designing state transitions so that if the same "Finish" command is received twice, the second one is safely ignored.
- **Timeouts & Recovery**: Adding logic to break a deadlock or clear a stalled workflow after a set amount of time.

## Examples
- **Podcast Domain**: 
    - *Fixing Deadlock*: All workers must lock `Episode` objects in order of their `UUID`.
    - *Fixing Missed Signal*: Using a `CountDownLatch` or a shared state flag that is checked before calling `await()`.
- **Order System**: A "Reconciliation Job" that runs every minute to find orders that are stuck in `PENDING_PAYMENT` and cancels them.

## Link to Assignment
- **A2 Alignment**: Part 7 of A2 requires you to "Repair the Coordination Design." This lecture provides the specific design patterns you should use to fix the failures you demonstrated in Part 5.
