# How to Force Failure

## Objective
- Learn techniques for making elusive concurrency bugs reproducible.
- Understand how to use timing delays and high load to expose race conditions.

## Key Concepts
- **Deterministic vs. Probabilistic Failure**: Moving from "it fails sometimes" to "it fails almost every time I run this test."
- **Sleep Injection**: Adding small, random `sleep()` or `delay()` calls between "Check" and "Act" to increase the race window.
- **Concurrent Test Harness**: Running many workers in a tight loop against the same object.
- **Repeatability**: Ensuring that once a failure is found, it can be triggered again to validate the eventual fix.

## Examples
- **Podcast Domain**: 
    - *Test*: Start 10 threads all trying to mark the same episode as `CLEANED`.
    - *Injection*: In the `clean()` method, add `Thread.sleep(10)` right after checking the current status but before updating it.
- **Load Injection**: Using a script to send 100 simultaneous requests to a single endpoint.

## Link to Assignment
- **A1 Alignment**: Part 4 of A1 requires you to "Inject Concurrency" and "Demonstrate Failure." This lecture provides the specific "tricks" (like adding delays) to ensure your system actually breaks so you can analyze it.
