# Why Locks Are Not the First Answer

## Objective
- Understand the "Design First" approach to concurrency over the "Patch First" approach.
- Evaluate the costs and risks associated with heavy reliance on locking.

## Key Concepts
- **Locking as a Patch**: Adding `synchronized` or `lock()` around flawed designs often hides rather than fixes the underlying state issues.
- **The Performance Cost**: How locks cause thread contention, context switching overhead, and reduced throughput.
- **Complexity Risk**: Locks introduce new failure modes, such as deadlocks, livelocks, and priority inversion.
- **Design Alternatives**: Exploring immutability, thread confinement, or better object boundaries before reaching for a mutex.

## Examples
- **Podcast Domain**: Instead of locking the whole `Episode` object, could you make the `Asset` objects immutable? Or could you ensure only one `Worker` is ever assigned to one `EpisodeID`?
- **Tradeoff Analysis**: Comparing a system that uses a single global lock (slow but simple) to one that uses fine-grained locking (fast but complex and dangerous).

## Link to Assignment
- **A1 Alignment**: In A1 Part 7, you are asked to "Redesign for Correctness." This lecture encourages you to think beyond just "adding a lock" and to consider if your object boundaries themselves need to change.
