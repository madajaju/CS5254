# What is Concurrency Really?

## Objective
- Distinguish between interleaving and parallelism.
- Understand how the CPU and operating system simulate simultaneous execution.

## Key Concepts
- **Interleaving**: Switching between tasks on a single core so rapidly that they appear to run at once.
- **Parallelism**: Truly running multiple tasks at the exact same time on multiple cores.
- **Context Switching**: The process of saving and restoring the state of a thread or process.
- **Non-Determinism**: Why concurrent programs can produce different results even with the same input.

## Examples
- **Podcast Domain**: 
    - *Parallelism*: One core cleans audio while another core generates a transcript.
    - *Interleaving*: A single-core machine switches between cleaning audio and generating a transcript every few milliseconds.
- **Race Condition**: Two interleaved threads both reading a value, both incrementing it in their own register, and then both writing it back, losing one increment.

## Link to Assignment
- **A1 Alignment**: This lecture provides the conceptual foundation for A1 Part 4, where you will inject "real" concurrency into your system to expose the flaws of your sequential design.
