# Shared State is the Problem

## Objective
- Understand why mutable shared state is the root cause of most concurrency issues.
- Explore the difference between local (safe) and shared (unsafe) state.

## Key Concepts
- **Mutable Shared State**: Data that can be changed (mutable) and is accessed by more than one thread (shared).
- **Thread Safety**: The property of an object or function that guarantees correct behavior when accessed by multiple threads.
- **State Leakage**: When an internal data structure is exposed, allowing external threads to modify it without the object's knowledge.

## Examples
- **Podcast Domain**: 
    - *Unsafe*: A global `static List<Episode> allEpisodes` that multiple workers add to and remove from.
    - *Safe*: A local `List<Asset> localAssets` that only exists within one worker's method execution.
- **Inventory System**: A shared `Integer count` being decremented by multiple purchase threads.

## Link to Assignment
- **A1 Alignment**: In A1 Part 1, you must identify your "shared mutable state." This lecture helps you distinguish which parts of your object model are actually shared and therefore need protection in Part 6.
