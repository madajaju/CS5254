# Race Conditions Step-by-Step

## Objective
- Visualize and analyze race conditions through timeline analysis.
- Understand how specific interleavings lead to lost updates or inconsistent state.

## Key Concepts
- **Timeline Analysis**: Mapping out exactly when each operation (Read, Modify, Write) happens across multiple threads.
- **Lost Update**: When two threads read the same initial value and overwrite each other's changes.
- **Check-Then-Act**: A common pattern where the condition checked becomes false between the check and the subsequent action.

## Examples
- **Podcast Domain**: 
    1. Worker A reads `episode.status` (value: `DRAFT`).
    2. Worker B reads `episode.status` (value: `DRAFT`).
    3. Worker A sets status to `PROCESSING`.
    4. Worker B sets status to `PROCESSING`.
    - *Result*: Duplicate work started because both workers passed the "is it a draft?" check.
- **Visual Mapping**: Drawing a vertical timeline with Thread 1 on the left and Thread 2 on the right to find the overlap.

## Link to Assignment
- **A1 Alignment**: Part 5 of A1 requires you to "demonstrate failure." This lecture teaches you how to analyze your logs to find these specific interleavings and prove that a race condition occurred.
