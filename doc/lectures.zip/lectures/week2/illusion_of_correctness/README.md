# The Illusion of Correctness

## Objective
- Recognize why single-threaded systems often appear correct while harboring fundamental design flaws.
- Identify the hidden assumptions that break when concurrency is introduced.

## Key Concepts
- **Sequential Bias**: The tendency to design logic assuming Step A *always* finishes before Step B starts.
- **Implicit Locks**: In a single-threaded system, the single thread acts as an implicit lock on all state. Removing this "lock" exposes the raw state.
- **Temporal Coupling**: When two parts of a system are dependent on each other's timing without explicit coordination.

## Examples
- **Podcast Domain**: An `Episode` update checks `if (status == DRAFT) { status = PROCESSING; }`. In a single-threaded test, this always works. In a concurrent system, two threads might both pass the check before either updates the status.
- **Order Fulfillment**: Deducting inventory. `if (stock > 0) { stock--; }`. Sequential runs never oversell; concurrent runs can result in negative stock.

## Link to Assignment
- **A1 Alignment**: In A1 Part 3, you'll demonstrate your "successful" single-threaded case. This lecture explains why that success is an "illusion" that will be shattered in Part 4.
