# State & Invariants

## Objective
- Define what constitutes a "correct" system state through the use of invariants.
- Learn how to identify and document these invariants in your system design.

## Key Concepts
- **System State**: The collective values of all data in the system at a point in time.
- **Invariants**: Conditions that must *always* be true for the system to be considered correct.
- **State Transitions**: The valid ways the system can move from one correct state to another.
- **Invariant Violation**: When concurrent operations leave the system in an impossible or illegal state.

## Examples
- **Podcast Domain**:
    - *Invariant*: "An episode cannot be `PUBLISHED` unless its `AudioFile` is marked as `CLEANED`."
    - *Invariant*: "There can never be more than one `Transcript` for a single `Episode` ID."
- **Order Fulfillment**:
    - *Invariant*: "Total inventory count cannot be negative."

## Link to Assignment
- **A1 Alignment**: You must identify and document specific invariants for your chosen domain in A1. These invariants will be the metrics you use to prove your system has "failed" when you add concurrency.
