# Object Boundaries & Responsibilities

## Objective
- Define clear boundaries between objects to minimize shared mutable state and clarify ownership.
- Understand the impact of poor encapsulation on concurrent systems.

## Key Concepts
- **Encapsulation of State**: Ensuring that an object's internal state can only be modified through its own methods.
- **Single Responsibility Principle (SRP)**: Each object should have one clear purpose (e.g., `Episode` tracks status, `Processor` handles logic).
- **Leaky Abstractions**: When an object exposes its internal data structures, allowing external entities to bypass its invariants.

## Examples
- **Podcast Domain**: An `Episode` object should own its `Status`. A `Worker` shouldn't just reach in and change the status field; it should call `episode.transitionToProcessing()`.
- **Bad Design**: A global `Map<EpisodeId, Status>` that any part of the system can modify at any time.

## Link to Assignment
- **A1 Alignment**: You are required to create at least three interacting objects. This lecture helps you decide what state each object "owns" and how they should interact.
