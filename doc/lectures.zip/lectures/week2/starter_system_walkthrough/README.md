# Starter System Walkthrough

## Objective
- Walk through the "Lecture System" to understand how to map objects, responsibilities, and intended flaws.
- Provide a template for your own A1 implementation.

## Key Concepts
- **Conceptual Baseline**: Using a simple system (e.g., a basic Task Tracker) to illustrate design patterns.
- **Mapping Responsibilities**: Seeing how a "Task" object and a "Worker" object interact.
- **Identifying Flaws**: Recognizing where the baseline system is vulnerable (e.g., a shared list without protection).

## Examples
- **Lecture System**: A simple Job Queue where multiple workers pull jobs. 
- **Intended Flaw**: The "pull" logic isn't atomic, allowing two workers to claim the same job.

## Link to Assignment
- **A1 Alignment**: Part 0 of A1 requires you to document the baseline system presented here and adapt it to your domain. This lecture is the direct source for that requirement.
