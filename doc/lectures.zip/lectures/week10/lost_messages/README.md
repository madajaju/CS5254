# Lost Messages

## Objective
- Understand the reality of unreliable networks and how messages can simply "disappear."
- Identify the gaps in systems that assume 100% message delivery.

## Key Concepts
- **Silent Failures**: A producer sends a message, assumes it worked, but the message never reaches the queue or the consumer.
- **Zombie Workflows**: Workflows that stay in an "In Progress" state forever because the "Finish" event was lost.
- **Broker Failures**: When the message queue itself crashes or loses persistent data.

## Examples
- **Podcast Domain**: 
    - *Scenario*: The `AudioCleaner` finishes and sends `AudioCleaned`. The message is dropped. The `Orchestrator` never proceeds to the next stage, and the `Episode` is stuck in `PROCESSING` forever.
- **Order System**: A user pays, but the `PaymentConfirmed` event is lost, so the order is never shipped.

## Link to Assignment
- **A3 Alignment**: "Lost event/message" is a mandatory demonstration in A3 Part 6. This lecture shows you how to simulate this by adding a "drop probability" to your message passing code.
