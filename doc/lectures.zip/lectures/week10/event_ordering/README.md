# Out-of-Order Events

## Objective
- Analyze how network latency and parallel processing lead to events arriving in a different order than they were sent.
- Understand the impact of out-of-order events on system state.

## Key Concepts
- **Non-FIFO Queues**: Many distributed queues do not guarantee that the first message in will be the first message out.
- **Race to the Consumer**: Two events are sent (A then B), but Event B is picked up by a faster worker and finishes before Event A.
- **State Regression**: When an older event arrives after a newer one and potentially overwrites more recent data.

## Examples
- **Podcast Domain**:
    - *Scenario*: The `EpisodeApproved` event is sent, then the `EpisodePublished` event is sent. Due to network jitter, `Published` arrives first. The system fails because it thinks the episode hasn't been approved yet.
- **Order System**: A `CancelOrder` event arriving before the `CreateOrder` event.

## Link to Assignment
- **A3 Alignment**: Part 6 of A3 requires you to demonstrate "out-of-order event handling." This lecture teaches you how to simulate this by adding different `sleep()` values to your background workers.
