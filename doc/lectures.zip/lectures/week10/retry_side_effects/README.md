# Retry Side Effects

## Objective
- Analyze how automatic retries can inadvertently cause multiple side effects.
- Understand the difference between retrying a "pure" function and an "impure" one.

## Key Concepts
- **Retry Storms**: When multiple failed workers all retry at the same time, overwhelming the downstream system.
- **Partial Success Failure**: A worker does 50% of its task (e.g., writes a file), then fails. On retry, it tries to write the file again, causing a conflict or duplication.
- **Zombie Resources**: Creating multiple copies of a resource (e.g., cloud VMs or temporary files) because of repeated retries.

## Examples
- **Podcast Domain**: 
    - *Scenario*: The `Publisher` starts uploading a 1GB file. At 99%, the network drops. The system retries. If the publishing platform doesn't support resumable uploads, you've now consumed 2GB of bandwidth and might have two partial files on the server.
- **Order System**: Charging a credit card, but failing to update the local database. The retry attempts to charge the card *again*.

## Link to Assignment
- **A3 Alignment**: Part 6 of A3 requires you to show a "retry causing duplicate side effects." This lecture helps you identify which parts of your workflow are "dangerous" to retry without proper safeguards.
