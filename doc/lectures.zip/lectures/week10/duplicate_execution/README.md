# Duplicate Execution

## Objective
- Understand why duplicate messages and executions are inevitable in asynchronous systems.
- Learn to identify the risks of redundant processing.

## Key Concepts
- **At-Least-Once Delivery**: A common guarantee where a message is guaranteed to be delivered but might be delivered more than once.
- **Double Processing**: When two different workers pick up the same task, or one worker picks it up twice.
- **Side Effect Inflation**: The negative impact of doing the same work twice (e.g., charging a customer twice, sending two notifications).

## Examples
- **Podcast Domain**:
    - *Scenario*: The `AudioCleaner` finishes its work but the "Success" acknowledgement is lost on the network. The queue re-delivers the `CleanJob`. A second worker starts cleaning the same file.
- **Order System**: Double-shipping an order because the `ShipOrder` event was processed by two redundant workers.

## Link to Assignment
- **A3 Alignment**: Part 6 of A3 requires you to "Demonstrate Async Failure Modes," specifically "duplicate event processing." This lecture explains how to trigger this by manually re-sending a message or simulating a network timeout.
