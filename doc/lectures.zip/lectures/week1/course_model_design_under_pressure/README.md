# Course Model: Design Under Pressure

## Objective
- Understand why standard object-oriented systems often fail when introduced to concurrent execution.
- Recognize the "Design → Break → Understand → Fix → Validate" cycle used throughout the course.
- Align assignment progression with the goal of building resilient systems.

## Key Concepts
- **The "Happy Path" Trap**: Single-threaded designs that look correct but harbor hidden assumptions about execution order.
- **Concurrency Pressure**: The application of multiple simultaneous operations to expose architectural flaws.
- **Iterative Resilience**: Building a system, intentionally breaking it with concurrency, and redesigning it to be robust.

## Examples
- **Podcast Domain**: An `Episode` object that tracks status. In a single-threaded environment, transitioning from `DRAFT` to `PUBLISHED` is simple. Under pressure, multiple workers might try to publish the same episode simultaneously, leading to duplicate notifications or inconsistent states.
- **Order Fulfillment**: Two workers trying to fulfill the same `Order` at the exact same millisecond. Without proper design, both might think they succeeded, double-shipping the product.

## Link to Assignment
- **A1 Alignment**: This lecture sets the stage for A1, where you will implement a baseline system that is *intended* to fail when you inject concurrency in Part 2. It introduces the mindset needed to document your baseline assumptions.
