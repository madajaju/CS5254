# Two-Stack Strategy

## Objective
- Understand why comparing implementations across two different runtime environments (stacks) exposes hidden assumptions.
- Learn how to maintain parity between two different language ecosystems.

## Key Concepts
- **Runtime Variance**: How different languages (e.g., Java vs. Node.js) handle threading, event loops, and memory differently.
- **Conceptual Parity**: Ensuring the *design* is the same even if the *syntax* differs.
- **Hidden Assumptions**: Discovering that a design works in one stack "by accident" (e.g., because of a Global Interpreter Lock) but fails in another.

## Examples
- **Stacks**: Implementing the Podcast system in **Java** (multi-threaded) and **Node.js** (single-threaded event loop).
- **Comparison**: In Java, you might see race conditions on a shared variable immediately. In Node.js, you might only see them when introducing `await` on a database call, which yields the execution context.

## Link to Assignment
- **A1 Alignment**: A1 requires you to implement your baseline system in two stacks. This lecture helps you plan how to keep those implementations aligned so that your concurrency tests are meaningful in both environments.
