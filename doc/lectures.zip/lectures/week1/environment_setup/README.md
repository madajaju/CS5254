# Environment & Repo Structure

## Objective
- Set up a professional development environment that supports multi-stack execution and structured observability.
- Establish a consistent repository layout for the semester.

## Key Concepts
- **Containerization (Docker)**: Using Docker to ensure consistent behavior across different developer machines and stacks.
- **Repo Layout**: Organizing `doc/`, `src/stack-a/`, `src/stack-b/`, and `integrity-packet/` for clear navigation.
- **Execution Basics**: How to run your system, inject configuration, and capture output.
- **Structured Logging Setup**: Ensuring your logging library is ready to output JSON or consistent formats for later analysis.

## Examples
- **Repo Structure**:
    - `doc/lectures/`
    - `doc/assignments/`
    - `src/java-service/`
    - `src/node-service/`
    - `scripts/run-concurrent-test.sh`

## Link to Assignment
- **A0 Alignment**: This lecture guides the technical setup required for A0. By the end of this week, you should be able to run a "Hello World" equivalent in both of your chosen stacks within the repo.
