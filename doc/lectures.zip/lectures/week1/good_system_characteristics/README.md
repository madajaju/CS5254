# What Makes a “Good System” for This Course

## Objective
- Identify system domains that provide sufficient complexity for exploring concurrency and coordination.
- Define the criteria for a "good system" within the context of CS 5891.

## Key Concepts
- **Shared State**: The system must have data (state) that is accessed or modified by multiple entities/workers.
- **Multi-step Workflows**: Logic should span multiple stages (e.g., Ingest -> Process -> Notify) where the order of operations matters.
- **Failure Potential**: The domain must naturally allow for race conditions, deadlocks, or partial failures if not handled correctly.
- **Domain Suitability**: A system that is too simple (CRUD only) or too complex (full distributed database) won't work well for these assignments.

## Examples
- **Podcast Production**: Multiple assets (audio, transcript, art) must be ready before publishing. This involves shared state (`Episode`) and multi-step coordination.
- **Order Fulfillment**: Inventory management, payment processing, and shipping updates. Concurrent orders for the last item in stock provide a classic failure case.
- **Distributed Job Processing**: Workers picking up tasks from a queue and updating a central status registry.

## Link to Assignment
- **A0 Alignment**: This lecture helps you choose your project domain for the semester. You will use these criteria to justify why your selected system (from `doc/projects/`) is a valid choice for the course.
