# AI-Generated Designs: Common Flaws

## Objective
- Develop a critical eye for AI-generated code, specifically regarding concurrency and architectural assumptions.
- Learn how to spot the "Classic AI Hallucinations" in system design.

## Key Concepts
- **Thread-Safety Hallucinations**: AI often claims a piece of code is thread-safe simply because it uses "safe" sounding keywords like `volatile` or `atomic` incorrectly.
- **Missing Edge Cases**: AI tends to ignore high-contention scenarios, network partitions, or partial system failures.
- **Complexity Overload**: AI may suggest overly complex solutions (like a full Distributed Lock Manager) for a simple local state problem.
- **Assumed Atomicity**: AI often assumes that a sequence of steps (Check -> Read -> Write) is atomic because it is written in one function.

## Examples
- **Podcast Domain**: You ask AI for a "safe status update." It gives you code using a `ConcurrentHashMap` but doesn't realize that your *logic* (checking status before updating) still has a race condition between the check and the update.
- **Critique**: Identifying that the AI ignored the "Transcript ingestion" dependency when suggesting a "Publishing" fix.

## Link to Assignment
- **A1 Alignment**: Part 8 of A1 is the "AI-Assisted Design Review." This lecture teaches you how to identify the "two flaws, risks, or missing assumptions" required for that section of your report.
