# Object Ownership & Thread Confinement

## Objective
- Learn how to prevent race conditions by ensuring that only one thread can "own" or access a specific object at any given time.
- Understand the "Hand-off" pattern for state.

## Key Concepts
- **Thread Confinement**: Restricting an object's access to a single thread so that no synchronization is needed.
- **Ownership Transfer**: The process of "handing off" an object from Thread A to Thread B. Once Thread B has it, Thread A can no longer access it.
- **Single-Writer Principle**: Allowing multiple threads to read an object but only one dedicated thread to write to it.

## Examples
- **Podcast Domain**: 
    - *Confinement*: A `Cleaner` thread owns the `AudioAsset` while it is cleaning it. No other thread even has a reference to it during this time.
    - *Hand-off*: Once cleaning is done, the `Cleaner` thread passes the `AudioAsset` to the `Publisher` thread and clears its own reference.
- **Queue-Based Ownership**: Placing an object into a queue effectively "hands off" ownership to the consumer of that queue.

## Link to Assignment
- **A1 Alignment**: This lecture provides a non-locking alternative for your Part 7 redesign. You can solve A1 failures by redesigning your system so that shared state is no longer actually shared between threads.
