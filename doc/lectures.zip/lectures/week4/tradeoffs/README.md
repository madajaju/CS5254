# Tradeoffs

## Objective
- Evaluate the impact of different concurrency fixes on system performance, simplicity, and correctness.
- Learn how to make informed architectural decisions.

## Key Concepts
- **Performance vs. Correctness**: A global lock is 100% correct but may be 100x slower than concurrent execution.
- **Complexity vs. Simplicity**: Immutability is often simpler to reason about but may use more memory.
- **Throughput vs. Latency**: Some fixes might handle more requests per second (throughput) but make individual requests take longer (latency).
- **Maintenance Burden**: Complex locking logic is harder for future developers to maintain without introducing bugs.

## Examples
- **Podcast Domain**: 
    - *Decision*: Should we use a global lock on the `EpisodeStore` or per-episode locks?
    - *Analysis*: Per-episode locks allow more concurrent episodes to be processed at once but increase the risk of deadlocks if an operation needs two episodes.
- **Immutability Tradeoff**: Creating a new 10MB `Transcript` object for every small edit might cause garbage collection issues (performance hit).

## Link to Assignment
- **A1 Alignment**: Part 7 of A1 explicitly asks you to "Explain the tradeoffs" of your chosen corrective approach. This lecture provides the framework for that explanation.
