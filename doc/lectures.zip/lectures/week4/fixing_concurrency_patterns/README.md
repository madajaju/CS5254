# Fixing Concurrency Patterns

## Objective
- Learn the three primary ways to fix concurrency issues: Locking, Immutability, and Message Passing.
- Understand when to apply each pattern.

## Key Concepts
- **Locks (Mutual Exclusion)**: Ensuring only one thread can access a code block at a time.
- **Immutability**: Designing objects so their state cannot change after creation, making them naturally thread-safe.
- **Message Passing (Actors/Channels)**: Threads communicate by sending data rather than sharing memory.
- **Atomicity**: Operations that appear to happen all at once or not at all.

## Examples
- **Podcast Domain**:
    - *Locking*: Using a `ReentrantLock` around the `episode.publish()` method.
    - *Immutability*: Creating a new `Episode` object with the updated status instead of modifying the existing one.
    - *Message Passing*: A worker sends a `CleanupComplete` message to a central `Orchestrator` instead of updating a shared database directly.

## Link to Assignment
- **A1 Alignment**: Part 7 of A1 requires you to implement one of these corrective approaches. This lecture provides the technical blueprint for those fixes.
