# Blocking is the Enemy of Scale

## Objective
- Understand why blocking calls limit the scalability and responsiveness of modern systems.
- Identify blocking points in your existing A2 coordinated design.

## Key Concepts
- **Blocking Call**: A thread waits for a response (e.g., from a database or another component) and cannot do anything else during that time.
- **Resource Saturation**: When all threads in a pool are blocked, the system stops accepting new work, even if the CPU is mostly idle.
- **Throughput Bottlenecks**: How sequential blocking steps add up to slow the overall system down.

## Examples
- **Podcast Domain**: 
    - *Blocking*: The `Orchestrator` waits for the `AudioCleaner` to finish. If 10 episodes are being cleaned, and we only have 10 threads, the 11th episode has to wait, even if other components are free.
- **Order System**: Waiting for an external Payment Gateway to respond (which might take 5 seconds) while the thread remains idle.

## Link to Assignment
- **A3 Alignment**: Part 1 of A3 requires you to "Identify at least two blocking or tightly coupled interactions in your A2 system." This lecture gives you the tools to find those bottlenecks.
