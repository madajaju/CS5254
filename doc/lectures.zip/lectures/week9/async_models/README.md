# Async Models Across Languages

## Objective
- Compare how different language runtimes (Java, Node.js, Go, Python) implement asynchronous execution.
- Learn how to achieve comparable behavior in your two stacks.

## Key Concepts
- **Node.js (Event Loop)**: Single-threaded but non-blocking using callbacks and `async/await`.
- **Java (Threads/Futures)**: Traditionally multi-threaded; modern Java uses `CompletableFuture` and Virtual Threads (Project Loom).
- **Go (Goroutines/Channels)**: Light-weight "green" threads that communicate via channels.
- **Python (Asyncio)**: An event loop model similar to Node.js but with different syntax and constraints.

## Examples
- **Two-Stack Comparison**: 
    - *Java*: Using a `ScheduledExecutorService` to simulate a background task.
    - *Node.js*: Using `setImmediate()` or a local `EventEmitter` to move work off the main path.
- **Syntactic Parity**: Mapping `await` in JavaScript to `.get()` or `.thenAccept()` in Java.

## Link to Assignment
- **A3 Alignment**: Part 3 of A3 requires you to "Implement comparable async behavior in both selected stacks." This lecture provides the technical patterns for each of the primary course languages.
