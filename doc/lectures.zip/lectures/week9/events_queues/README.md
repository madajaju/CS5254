# Events, Queues, Workers

## Objective
- Learn the building blocks of event-driven architecture.
- Understand the role of producers, consumers, and message brokers.

## Key Concepts
- **Event**: A record of something that *happened* in the past (e.g., `OrderPlaced`).
- **Queue**: A buffer that stores events until they can be processed by a consumer.
- **Worker (Consumer)**: A component that pulls events from a queue and performs an action.
- **Decoupling**: The producer doesn't need to know who is consuming the event or if they are even online.

## Examples
- **Podcast Domain**:
    - `EpisodeIngestor` (Producer) puts a `RawAudioReady` message on a `CleanupQueue`.
    - `AudioCleaner` (Worker) pulls from the queue, cleans the file, and puts a `AudioCleaned` message on a `TranscriptionQueue`.
- **Order System**: `Checkout` sends `PaymentRequested` to a task queue.

## Link to Assignment
- **A3 Alignment**: Part 2 of A3 requires you to "Define event/message types, producer objects, and consumer objects." This lecture provides the terminology and architectural diagram for that requirement.
