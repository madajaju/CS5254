# Designing Async Systems

## Objective
- Apply asynchronous patterns to a real-world system design.
- Learn how to map state transitions to events.

## Key Concepts
- **Event Storming**: Identifying all the significant events in a domain.
- **Workflow Orchestration (Async)**: Using an "Orchestrator Worker" to manage complex async logic.
- **Error Propagation**: How to handle failures in a background worker where there is no user waiting for a response.
- **Observability**: The increased importance of Correlation IDs when work is spread across different workers and timeframes.

## Examples
- **Podcast Domain**: Mapping the A2 sequential workflow (Ingest -> Clean -> Transcribe) to a chain of async events.
- **Design Decision**: Choosing between one large "Job" object or multiple small "Event" messages.

## Link to Assignment
- **A3 Alignment**: Part 2 of A3 requires you to "Design an Asynchronous Architecture." This lecture provides the design methodology for transforming your A2 blocking system into the required A3 async system.
