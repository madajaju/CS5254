# Synchronization Mechanisms

## Objective
- Explore the technical tools used to synchronize the execution of multiple threads or components.
- Understand the trade-offs between different primitive and high-level mechanisms.

## Key Concepts
- **Locks & Mutexes**: Preventing simultaneous access to a resource.
- **Signals & Condition Variables**: Allowing one thread to wake up another thread when a condition is met (e.g., `notify()` / `wait()`).
- **Queues**: Using a buffer to pass work between producers and consumers, naturally handling rate differences and providing ordering.
- **Futures & Promises**: Objects representing the result of an asynchronous operation that hasn't finished yet.

## Examples
- **Podcast Domain**: 
    - *Signal*: The `AudioProcessor` signals the `TranscriptGenerator` when the audio file is ingested.
    - *Queue*: Placing a `CleaningJob` on a queue for the `AudioCleaner` to pick up.
- **Order System**: A `Semaphore` to limit the number of simultaneous payment processing requests to an external API.

## Link to Assignment
- **A2 Alignment**: Part 3 of A2 requires you to use at least one coordination mechanism (Locks, Signals, Queues, etc.) in both of your stacks. This lecture explains how each of those tools works.
