# Workflow Design Example

## Objective
- Walk through a complete design for a coordinated workflow in the Podcast and Order domains.
- See how to document coordination rules and identify potential failure points.

## Key Concepts
- **Workflow Mapping**: Visualizing the stages and the objects responsible for them.
- **Fail-Fast Design**: Identifying points where the workflow should stop immediately if an invariant is violated.
- **Observability in Workflows**: Designing log messages that show the "handoff" between objects.

## Examples
- **Podcast Walkthrough**:
    1. `Ingestor` receives file -> updates `Episode` to `INGESTED`.
    2. `Ingestor` signals `Cleaner`.
    3. `Cleaner` completes -> updates `Episode` to `CLEANED`.
    4. `Orchestrator` checks if `Transcript` is also done.
- **Order Walkthrough**: Payment -> Inventory Reservation -> Shipping.

## Link to Assignment
- **A2 Alignment**: This walkthrough provides the "Lecture System" equivalent for A2. You can use the diagrams and logic shown here as a template for your own A2 `README.md` workflow documentation.
