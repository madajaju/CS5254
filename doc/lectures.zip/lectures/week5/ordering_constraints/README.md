# Ordering Constraints

## Objective
- Define and enforce the rules that govern the sequence of operations in a workflow.
- Identify data and logical dependencies between steps.

## Key Concepts
- **Sequential Dependencies**: Step B *requires* the output of Step A.
- **Parallel Steps**: Steps C and D can happen at the same time but both must finish before Step E.
- **Pre-conditions & Post-conditions**: The state that must exist before a stage starts and the state that is guaranteed when it finishes.
- **Gating**: Preventing a workflow from proceeding until specific criteria are met (e.g., an `ApprovalGate`).

## Examples
- **Podcast Domain**:
    - *Constraint*: You cannot generate show notes until the transcript is ready.
    - *Constraint*: You cannot publish until *both* the cleaned audio and the show notes are complete.
- **Order System**: You cannot ship an item that hasn't been paid for.

## Link to Assignment
- **A2 Alignment**: Part 2 of A2 requires you to "Define Coordination Rules" (e.g., "Stage B cannot start until Stage A completes"). This lecture shows you how to identify these constraints in your domain.
