# Coordination Patterns

## Objective
- Compare and contrast different architectural patterns for coordinating multiple components.
- Understand the pros and cons of Centralized vs. Distributed coordination.

## Key Concepts
- **Centralized Coordination (Orchestration)**: A single "Coordinator" object manages the entire workflow and tells other objects what to do.
- **Distributed Coordination (Choreography)**: Objects interact with each other directly or via events to move the workflow forward without a central manager.
- **Coupling**: How dependent objects are on each other's existence and internal logic.
- **Visibility**: How easy it is to see the "current state" of the entire workflow.

## Examples
- **Centralized**: A `WorkflowManager` that calls `audioCleaner.clean()`, waits, then calls `transcriptGenerator.generate()`.
- **Distributed**: `AudioCleaner` finishes its work and then calls `transcriptGenerator.start()`, or emits an `AudioCleaned` event that the generator listens for.

## Link to Assignment
- **A2 Alignment**: This lecture helps you decide on the "Coordination Strategy" required for A2. You will eventually compare your chosen strategy against an alternative in Part 8.
