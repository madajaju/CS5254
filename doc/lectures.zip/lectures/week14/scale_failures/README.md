# Where Systems Break at Scale

## Objective
- Identify the physical and logical limits of your current design.
- Understand how "Correct" small systems become "Broken" large systems.

## Key Concepts
- **Linear vs. Non-Linear Scalling**: When doubling the work more than doubles the time or resources required.
- **Single Point of Contention**: A shared resource (like a global lock or a single database row) that every worker must wait for.
- **Resource Exhaustion**: Running out of file handles, sockets, or memory due to too many "In-Flight" async tasks.
- **Amortized Cost**: The hidden costs of coordination that become dominant at high scale.

## Examples
- **Podcast Domain**: 
    - *Limit*: Your system stores all `Episode` objects in a single `List` in memory.
    - *Break Point*: At 1,000,000 episodes, the system crashes with `OutOfMemoryError` or search time becomes unusable.
- **Order System**: A central database lock on the `Inventory` table that prevents more than 50 orders per second regardless of how many workers you add.

## Link to Assignment
- **A4 Alignment**: Part 7 of A4 asks you to "Include where the system would fail at larger scale." This lecture provides the terminology (Contention, Saturation, Non-Linearity) to answer that question professionally.
