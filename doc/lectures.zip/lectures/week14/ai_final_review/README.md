# AI Final Review: What Was Learned?

## Objective
- Perform a final assessment of AI's role in the system development lifecycle.
- Synthesize all AI critiques from A1–A4 into a set of "Best Practices for AI Collaboration."

## Key Concepts
- **The Competency Gap**: Identifying the specific areas where you (the human) consistently caught issues that the AI missed (e.g., deep race conditions).
- **The Acceleration Factor**: Quantifying where AI actually helped (e.g., generating boilerplate, suggesting standard patterns).
- **Validation as the Constant**: The realization that as systems grow more complex, the need for human-led validation increases rather than decreases.
- **Prompt Evolution**: How your ability to "talk to the AI" about concurrent systems improved over the semester.

## Examples
- **Reflection**: In A1, the AI suggested a fix that you blindly accepted and then watched fail. In A4, you used the AI to critique your "Recovery Design" and you found two hallucinations in its response before even writing code.
- **Verification**: Documenting that you rejected an AI's suggestion for a "Distributed Saga" because it was overkill for your local stress test.

## Link to Assignment
- **A4 Alignment**: This lecture supports Part 8 of A4: "AI-Assisted Final Review." It helps you move beyond just "finding bugs" to "evaluating the collaboration" for your final report.
