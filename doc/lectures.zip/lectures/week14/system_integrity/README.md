# System Integrity Under Pressure

## Objective
- Synthesize all course concepts to define and preserve system integrity under high load and failure conditions.
- Prepare the final argument for why your system is "correct."

## Key Concepts
- **System Integrity**: The property where a system maintains its invariants and data consistency regardless of concurrency, load, or partial failure.
- **The Integrity Chain**: How object boundaries, synchronization, coordination rules, and async controls work together to prevent corruption.
- **Defense in Depth**: Applying multiple layers of protection (e.g., a state machine guard *and* an idempotency key).

## Examples
- **Podcast Domain**: Showing that even if the `Cleaner` fails, the `Orchestrator` retries, and if the `Publisher` receives two events, the `IdempotencyKey` prevents duplicate uploads, ensuring the episode always reaches exactly one `PUBLISHED` state.
- **Validation**: Using logs to show that "Zero Invariant Violations" occurred during the 100-episode stress test.

## Link to Assignment
- **A4 Alignment**: This lecture directly supports Part 7 of A4: "Final Integrity Packet." It helps you summarize your "Evidence Summary" and "Major Assumptions" into a cohesive defense of your system.
