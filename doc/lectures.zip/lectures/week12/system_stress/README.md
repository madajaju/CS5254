# What is System Stress?

## Objective
- Define "System Stress" beyond just high CPU usage.
- Understand how concurrency and asynchronous execution create pressure on system invariants.

## Key Concepts
- **Stress**: Pushing the system to its operational limits (e.g., maximum threads, memory, or throughput).
- **Contention**: When multiple threads fight for the same resource (lock, database connection, or queue slot).
- **Saturation**: The point where adding more work leads to a decrease in performance rather than just a plateau.
- **Edge Cases**: Rare timing combinations that only appear when the system is under heavy load.

## Examples
- **Podcast Domain**: 
    - *Stress*: Processing 50 episodes simultaneously, each with 5 assets.
    - *Result*: You might find that your "In-Memory Map" of episodes is growing too large, or your workers are timing out because the CPU is 100% utilized.
- **Order System**: 1,000 concurrent orders for a single high-demand item.

## Link to Assignment
- **A4 Alignment**: Part 2 of A4 requires you to "Add Stress Conditions" (at least 10 concurrent operations). This lecture helps you define what "stress" looks like for your specific domain and how to measure its impact.
