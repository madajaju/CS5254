# Observability Under Stress

## Objective
- Learn how to identify system bottlenecks and failures when logs are interleaved at massive scale.
- Understand the "Noise" problem in high-load logging.

## Key Concepts
- **Log Aggregation**: Combining logs from multiple workers into a single view.
- **Filtering by Pressure**: Using tools (like `grep` or JSON parsers) to find only the logs where latency exceeded a threshold.
- **Visualizing Queue Depth**: Logging the size of your task queues to see if workers are falling behind.
- **The "Missing Log"**: Understanding that under extreme stress, the logging system itself might fail or drop entries.

## Examples
- **Podcast Domain**: 
    - *Analysis*: Noticing that `Cleaner` logs are 500ms apart under normal load, but 5000ms apart under stress.
    - *Deduction*: The `Cleaner` worker pool is saturated and episodes are waiting in the queue.
- **Trace Analysis**: Using Correlation IDs to pull out the "Path of One Episode" from a 100,000-line stress log.

## Link to Assignment
- **A4 Alignment**: Part 2 of A4 requires you to "Capture logs or metrics" from your stress test. This lecture shows you how to interpret those logs to find the "Limits" of your system for your Final Integrity Packet.
