# Load Testing Basics

## Objective
- Learn how to build repeatable scripts to apply consistent load to your system.
- Distinguish between a "Functional Test" and a "Load Test."

## Key Concepts
- **Throughput (TPS/RPS)**: Transactions or Requests per second.
- **Latency (p95/p99)**: The time it takes for 95% or 99% of requests to complete.
- **Ramp-up**: Gradually increasing the load to see where the system starts to degrade.
- **Steady State**: Maintaining a consistent load over time to check for memory leaks or resource exhaustion.

## Examples
- **Podcast Domain**: 
    - *Script*: A loop that starts 5 new "Episode Workflows" every second for 60 seconds.
    - *Metrics*: Checking if the average time to `PUBLISHED` increases as more episodes are added.
- **Tools**: Using simple bash scripts with `curl` or `parallel` to hit your system's endpoints.

## Link to Assignment
- **A4 Alignment**: Part 2 of A4 requires a "repeatable stress script." This lecture provides the template for building that script and explains which metrics (like throughput and latency) you should capture in your logs.
