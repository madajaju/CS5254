# Idempotency

## Objective
- Understand how to design operations so that they can be safely executed multiple times without changing the result beyond the initial application.
- Learn how to implement idempotency keys and guards.

## Key Concepts
- **Idempotent Operation**: An operation that has no additional effect if it is called more than once with the same input parameters.
- **Idempotency Key**: A unique identifier (e.g., a UUID) sent with a request that the server uses to recognize and ignore duplicate requests.
- **Natural Idempotency**: Operations that are inherently safe to repeat (e.g., `SET status = 'PUBLISHED'` is idempotent; `INCREMENT count` is not).
- **Deduplication Table**: A storage mechanism to track which message IDs have already been processed.

## Examples
- **Podcast Domain**: 
    - *Unsafe*: `episode.addAsset(file)`. (Adds multiple assets if retried).
    - *Idempotent*: `episode.upsertAsset(assetId, file)`. (Updates or adds, but won't duplicate based on the `assetId`).
- **Order System**: Including a `client_request_id` with a payment request to prevent double-charging.

## Link to Assignment
- **A3 Alignment**: Part 7 of A3 requires adding "Correctness Controls" like an "idempotency key" or "deduplication." This lecture provides the implementation strategies for those controls.
