# State Machines

## Objective
- Learn how to use Finite State Machines (FSMs) to strictly control valid transitions and prevent illegal states in asynchronous systems.
- Understand how FSMs simplify reasoning about complex workflows.

## Key Concepts
- **States**: The set of possible conditions for an object (e.g., `DRAFT`, `CLEANING`, `PUBLISHED`).
- **Transitions**: The valid paths between states, triggered by specific events.
- **Illegal Transition Guard**: Logic that rejects an event if it doesn't match a valid transition from the current state (e.g., cannot move from `DRAFT` directly to `PUBLISHED`).
- **Deterministic Behavior**: Given a state and an event, the next state is always predictable.

## Examples
- **Podcast Domain**:
    - *Transition*: `INGESTED` + `CleanFinished` -> `CLEANED`.
    - *Guard*: If a `Publish` event arrives while the state is `INGESTED`, the FSM rejects it because the `CLEANED` state is a prerequisite.
- **Order System**: An order cannot be `SHIPPED` unless it is in the `PAID` state.

## Link to Assignment
- **A3 Alignment**: Part 7 of A3 lists "state machine" as a correctness control. This lecture shows you how to replace loose `if/else` logic with a formal state machine to eliminate "stale state read" or "invalid transition" errors.
