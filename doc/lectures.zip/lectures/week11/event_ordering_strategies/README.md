# Event Ordering Strategies

## Objective
- Explore techniques for ensuring that asynchronous events are processed in the correct logical order, even if they arrive out-of-order.
- Understand the trade-offs of different ordering mechanisms.

## Key Concepts
- **Sequence Numbers / Versioning**: Attaching a monotonically increasing number to each event so the consumer can detect gaps or old data.
- **Causal Ordering**: Ensuring that if Event B depends on Event A, B is never processed before A.
- **Buffering/Reordering**: Holding onto "early" events in a temporary buffer until the preceding events arrive.
- **Partitioning / Sharding**: Ensuring that all events for the same entity (e.g., `EpisodeID-1`) are handled by the same consumer in the order they were produced.

## Examples
- **Podcast Domain**: 
    - *Versioning*: Each `StatusUpdate` event includes a `version` number. If the consumer sees `version 5` but the current state is `version 3`, it waits for `version 4`.
- **Order System**: Ensuring `OrderCancelled` never results in an "Order Created" state if it arrives before `OrderCreated`.

## Link to Assignment
- **A3 Alignment**: Part 7 of A3 suggests "event sequencing" as a correctness control. This lecture provides the logic for using sequence numbers to reject or buffer out-of-order events.
