# Debugging Async Systems

## Objective
- Master the techniques for debugging systems where logic is distributed across time, threads, and workers.
- Learn how to leverage observability to find the root cause of async failures.

## Key Concepts
- **Event Tracing**: Following a single Correlation ID through multiple queues and workers to see where it stalled or failed.
- **State Snapshots**: Logging the entire state of an object before and after an async event is processed.
- **Visualizing Timelines**: Reconstructing the actual order of event processing from logs to find race conditions or ordering violations.
- **Analyzing Retries**: Identifying "retry loops" where a task fails, retries, and fails again in the exact same way.

## Examples
- **Podcast Domain**: Using a log aggregator to see that `Episode-123` was picked up by `Worker-A`, but no "Complete" log ever appeared, indicating the worker crashed or the message was lost.
- **Trace Analysis**: Seeing that a `Publish` event was processed *before* the `Cleaned` event, even though the `Cleaned` event was *sent* first.

## Link to Assignment
- **A3 Alignment**: Part 6 of A3 requires "logs or test output" to demonstrate failure. This lecture helps you refine your logging so that your evidence is clear and leads directly to the "Correctness Control" you implement in Part 7.
