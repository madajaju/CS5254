# Common Failure Patterns

## Objective
- Review and categorize the most common failures encountered in A1 and A2.
- Create a "Failure Catalog" for future system design.

## Key Concepts
- **Race Condition (Lost Update)**: Multiple writers, no protection.
- **Race Condition (Check-Then-Act)**: Reading stale state before deciding.
- **Deadlock**: Circular resource dependency.
- **Missed Signal**: Signaling an object that isn't yet in the "waiting" state.
- **Livelock**: Active but futile state changes.
- **Inconsistent Read**: Reading state while another thread is halfway through an update.

## Examples
- **Podcast Domain**: 
    - *Lost Update*: Two workers both increment the `AssetCount` but one update is lost.
    - *Inconsistent Read*: A summary report shows an episode as `PUBLISHED` but with zero `Assets`, because the assets were being added in another thread.
- **Categorization**: Grouping failures by whether they are solved by *Synchronization* (locking) or *Design* (immutability).

## Link to Assignment
- **Midterm Alignment**: The midterm will require you to identify these patterns in code snippets and log outputs. This lecture serves as the "Study Guide" for the failure identification portion of the exam.
