# System Reasoning Walkthrough

## Objective
- Develop the ability to analyze a live system's logs and behavior to deduce its internal state and identify flaws.
- Practice "Black Box" reasoning.

## Key Concepts
- **Deductive Reasoning**: Using external observations (logs, timings) to prove what must be happening inside the code.
- **Mental Modeling**: Building a conceptual map of the system's execution path without looking at the source code.
- **Hypothesis Testing**: Formulating a theory about a failure and then running a targeted test to prove or disprove it.

## Examples
- **Live Analysis**: Looking at a series of logs where `Episode-1` is published twice.
    - *Observation*: Thread A logs "Checking status" at 10.01ms. Thread B logs "Checking status" at 10.02ms.
    - *Deduction*: There is no locking between the check and the update.
- **Project Context**: Applying this reasoning to a student's project (e.g., an Order Fulfillment system) during a live critique.

## Link to Assignment
- **A1/A2 Review**: This lecture synthesizes everything learned in A1 and A2. It prepares you to "defend your design" by showing you how to reason about *any* concurrent system, not just the one you wrote.
