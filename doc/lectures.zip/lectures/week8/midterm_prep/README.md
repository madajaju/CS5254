# Midterm Preparation: How to Think, Not Memorize

## Objective
- Prepare for the midterm exam by focusing on system reasoning and pattern recognition.
- Shift the mindset from "knowing syntax" to "understanding execution."

## Key Concepts
- **Trace Analysis**: Given a code block and an interleaving, what is the final state?
- **Pattern Matching**: Identifying which failure (Race, Deadlock, etc.) is present in a flawed design.
- **Tradeoff Justification**: Explaining why a specific fix was chosen over another.
- **Integrity Reasoning**: Applying the "Integrity Packet" mindset to exam questions.

## Examples
- **Exam Style Question**: "Thread A runs `x = x + 1`. Thread B runs `x = x + 2`. If `x` starts at 0, what are the possible final values for `x`? Explain the interleaving that leads to each."
- **Failure Identification**: "Analyze this `WorkflowCoordinator` and find the deadlock risk."

## Link to Assignment
- **Synthesize A1 & A2**: The midterm is the formal validation of the skills developed in A1 and A2. This lecture provides practice problems and framing to ensure you are ready for the high-pressure reasoning required.
