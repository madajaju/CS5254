# Failure is Normal

## Objective
- Adopt a "Design for Failure" mindset.
- Understand that in concurrent and distributed systems, partial failure is an expected state, not an exception.

## Key Concepts
- **Partial Failure**: When one component of a system fails while the rest remains operational.
- **Fail-Fast**: Detecting an error as soon as possible and stopping the workflow to prevent data corruption.
- **Graceful Degradation**: Allowing the system to continue functioning with reduced features when a non-essential component fails.
- **Blast Radius**: Limiting the impact of a failure so it doesn't bring down the entire system.

## Examples
- **Podcast Domain**: 
    - *Scenario*: The `TranscriptionGenerator` (external API) is down. 
    - *Handling*: The system marks the episode as `TRANSCRIPTION_FAILED`, but still allows the `AudioCleaner` to finish its work and the `Editor` to preview the file.
- **Order System**: Inventory reservation succeeds, but the Payment Gateway is unreachable.

## Link to Assignment
- **A4 Alignment**: Part 3 of A4 requires you to "Inject Partial Failures." This lecture provides the conceptual framework for deciding how your system should react when a worker or service disappears.
