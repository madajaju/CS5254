# Retries, Compensation, Dead Letter Queues

## Objective
- Learn the technical patterns for recovering from or containing failures in an asynchronous workflow.
- Understand when to retry and when to give up.

## Key Concepts
- **Exponential Backoff**: Increasing the wait time between retries to avoid overwhelming a struggling downstream system.
- **Compensation (Rollback)**: Taking an action to "undo" a previous successful step because a subsequent step failed (e.g., refunding a payment if shipping fails).
- **Dead Letter Queue (DLQ)**: A separate queue where messages are moved after they have failed all retry attempts, allowing for manual inspection.
- **Circuit Breaker**: Temporarily stopping all requests to a failing component to give it time to recover.

## Examples
- **Podcast Domain**:
    - *Retry*: The `AudioCleaner` retries the file upload 3 times with increasing delays.
    - *DLQ*: If the file is still not uploaded, the message is moved to `failed-uploads-queue` for an admin to check.
- **Order System**: Refunding a credit card (Compensation) if the warehouse finds the item is actually out of stock after payment.

## Link to Assignment
- **A4 Alignment**: Part 4 of A4 requires "Recovery or Containment" mechanisms. This lecture provides the implementation details for Dead Letter Queues and Compensation steps.
