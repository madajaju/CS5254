# Designing for Recovery

## Objective
- Design systems that can return to a consistent state after a crash or major failure.
- Understand the role of persistence and state reconstruction.

## Key Concepts
- **Check-pointing**: Periodically saving the state of a long-running workflow so it can resume from the last known good point.
- **Reconciliation (Self-Healing)**: A background process that scans the system for "orphaned" or "stuck" objects and fixes them.
- **Stateless Workers**: Designing workers so they don't hold any critical state in memory, allowing them to be restarted without data loss.

## Examples
- **Podcast Domain**: 
    - *Scenario*: The whole system crashes while an episode is being rendered.
    - *Recovery*: On restart, a `ReconciliationJob` finds the episode in the `RENDERING` state, checks the output folder, sees the file is incomplete, and re-queues the `RenderTask`.
- **Order System**: Re-processing orders that are in `PENDING` for more than 1 hour.

## Link to Assignment
- **A4 Alignment**: Part 4 of A4 asks you to explain "what is recovered vs what is contained." This lecture helps you design the "Self-Healing" logic that allows your system to recover automatically from the failures you inject in Part 3.
