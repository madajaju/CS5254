# Centralized vs. Distributed Coordination

## Objective
- Compare the architectural trade-offs between having a single coordinator and having components coordinate themselves.
- Decide which model is appropriate for your A2 system.

## Key Concepts
- **Centralized (Orchestration)**: High visibility, easy to debug, but creates a single point of failure and a potential performance bottleneck.
- **Distributed (Choreography)**: Highly scalable, low coupling, but extremely difficult to trace the "big picture" of a workflow.
- **Bottlenecks**: When one component (the coordinator) cannot keep up with the volume of signals from other components.

## Examples
- **Podcast Domain**: 
    - *Centralized*: A `MasterOrchestrator` that keeps a state machine for every episode.
    - *Distributed*: The `AudioProcessor` calls the `TranscriptGenerator` directly when done.
- **Order System**: A central "Saga Coordinator" vs. a series of services listening to each other's events.

## Link to Assignment
- **A2 Alignment**: Part 8 of A2 requires you to "Compare Two Coordination Strategies." This lecture provides the specific pros and cons for the Centralized vs. Distributed comparison.
