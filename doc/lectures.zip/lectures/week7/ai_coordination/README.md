# AI Coordination Designs: Critique & Validation

## Objective
- Apply the critique skills learned in Week 4 to more complex multi-object coordination designs provided by AI.
- Learn how to validate AI's assumptions about ordering and synchronization.

## Key Concepts
- **Coordination Hallucinations**: AI often suggests coordination patterns (like "just use a global event bus") without explaining how to handle out-of-order events or duplicate signals.
- **Dependency Neglect**: AI might generate code for Stage B that completely ignores the required output from Stage A.
- **Validation by Trace**: Manually tracing the AI's logic with an "adversarial" interleaving to see if it results in a deadlock or missed signal.

## Examples
- **Podcast Domain**: You ask AI to "design a workflow where transcription and cleanup run in parallel." AI gives you two threads but no logic to join them before publishing. You must identify that the "Join" step is missing.
- **Critique**: "The AI's design assumes that the `notify()` will always happen after the `wait()`, but it provides no guard against the signal being sent early."

## Link to Assignment
- **A2 Alignment**: Part 9 of A2 is the "AI-Assisted Coordination Review." This lecture specifically prepares you to find the "two issues, risks, or missing assumptions" in a coordinated workflow design.
