# Simplicity vs. Scalability

## Objective
- Analyze the fundamental trade-off between a design that is easy to understand and a design that can handle high volumes of concurrent work.
- Learn when to sacrifice simplicity for the sake of system survival.

## Key Concepts
- **Cognitive Load**: How much effort it takes for a developer to understand the coordination logic.
- **Resource Saturation**: When the system's simple design (e.g., one thread per episode) hits the limits of the hardware (e.g., too much memory for thread stacks).
- **Scale-Up vs. Scale-Out**: Can the design handle more work by adding more cores? More machines?

## Examples
- **Podcast Domain**: 
    - *Simple*: A single Java process using `synchronized` blocks. Easy to write, works perfectly for 10 concurrent episodes, but crashes at 10,000.
    - *Scalable*: A distributed system with multiple microservices and message queues. Much harder to debug and deploy, but can handle millions of episodes.

## Link to Assignment
- **A2 Alignment**: This lecture provides the context for the "Strategy Comparison" in Part 8. It helps you articulate why you might choose a "less scalable" but "simpler" design for your specific project constraints.
