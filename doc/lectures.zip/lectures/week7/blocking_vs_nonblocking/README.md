# Blocking vs. Non-Blocking Coordination

## Objective
- Understand the impact of blocking operations on system throughput and thread utilization.
- Explore non-blocking alternatives like callbacks, futures, and async/await.

## Key Concepts
- **Blocking**: A thread stops and waits for a resource or signal, doing no other work in the meantime.
- **Non-Blocking**: A thread initiates an operation and provides a way to be notified when it's done, allowing the thread to work on other things.
- **Thread Starvation**: When all available threads are blocked waiting for signals, and the system can no longer process new requests.
- **Callbacks/Promises**: Tools for handling the completion of a non-blocking operation.

## Examples
- **Podcast Domain**: 
    - *Blocking*: The `Orchestrator` thread calls `cleaner.clean()` and sleeps until it returns.
    - *Non-Blocking*: The `Orchestrator` sends a request to the `Cleaner` and then immediately goes back to picking up new episodes from the ingestion queue.
- **I/O Wait**: Comparing blocking file reads vs. asynchronous non-blocking I/O.

## Link to Assignment
- **A2 Alignment**: Part 8 of A2 allows you to compare "blocking coordination vs future/promise coordination." This lecture explains the fundamental difference in how threads are used in each approach.
